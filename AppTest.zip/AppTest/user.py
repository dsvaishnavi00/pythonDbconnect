from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
db = client["test"]
users = db["users"]

def verify_user(username, password):
    user = users.find_one({"username": username, "password": password})
    if(user):
        return True
    else:
        return False
    
def add_user(username, password):
    user = users.find_one({"username"})
    if(user):
        print("User already exists")
        return False
        
    else:
        users.insert_one({"username": username, "password": password})
        return True