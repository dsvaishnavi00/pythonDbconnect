import json
from flask import Flask
from flask_cors import CORS, cross_origin
from flask import Flask, request,Response,jsonify

from user import verify_user

app = Flask(__name__)
cors = CORS(app)
cors = CORS(app, resource={
    r"/*":{
        "origins":"*"
    }
})
app.config['CORS_HEADERS'] = 'Content-Type'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

@app.route('/user/login', methods=['POST','GET'])
def user_login():
    if request.method == 'POST':
        try:
            inputjson = request.get_json()
        except TypeError:
            raise TypeError("Input not in the form of json")
        
        username = inputjson['username']
        password = inputjson['password']
        isuservalid =  verify_user(username,password)
        data ={
            "is_uservalid":isuservalid
        }

        response = app.response_class(
        response=json.dumps(data),
        status=200,
        mimetype='application/json'
    )
        return response
    
@app.route('/user/register', methods=['POST','GET'])
def user_register():
    if request.method == 'POST':
        try:
            inputjson = request.get_json()
        except TypeError:
            raise TypeError("Input not in the form of json")
        
        username = inputjson['username']
        password = inputjson['password']
        isuseradded =  verify_user(username,password)
        data ={
            "is_useradded":isuseradded
        }

        response = app.response_class(
        response=json.dumps(data),
        status=200,
        mimetype='application/json'
    )
        return response